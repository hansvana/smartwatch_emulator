var radioElements = document.getElementsByName("face");
for(var i = 0; i < radioElements.length; i++){
    radioElements[i].addEventListener("change", function(e) {
      changeFace(e.srcElement.value);
    });
}

var faces = {
  apple : {
    width: 272,
    height: 340,
    image: "applewatch.png",
    imgWidth: 709,
    imgHeight: 824
  },
  samsung : {
    width: 360,
    height: 360,
    image: "samsunggear.png",
    imgWidth: 850,
    imgHeight: 1016
  }
}

function changeFace(val) {
  var frame = document.getElementById("watchframe");
  var overlay = document.getElementById("overlay");
  var props = faces[val];

  if (props) {
    frame.style.width = props.width +"px";
    frame.style.height = props.height +"px";
    frame.style.marginLeft = - props.width/2 +"px";
    frame.style.marginTop = - props.height/2 +"px";
    overlay.style.width = props.imgWidth +"px";
    overlay.style.height = props.imgHeight +"px";
    overlay.style.marginLeft = - props.imgWidth/2 +"px";
    overlay.style.marginTop = - props.imgHeight/2 +"px";
    overlay.style.backgroundImage = "url(img/"+props.image+")";
  }

  localStorage.setItem("watch_face", val);
}

var face = localStorage.getItem("watch_face")

changeFace(face ? face : "apple");

function getFromStorage() {
    var src;
    try {
        src = JSON.parse(localStorage.getItem("watch_src"));
    } catch (e) {
        return false;
    }
    return src;
}

var src = getFromStorage();
var id = chrome.tabs.getCurrent( function(tab){
    return tab.id;
} );

console.log(src);

if (src && src.id === id) {
  document.getElementById("watchframe").src = src.url;
} else {
  chrome.runtime.sendMessage({action: "geturl"}, function(response) {
      document.getElementById("watchframe").src = response.url;
      localStorage.setItem("watch_src", JSON.stringify({id: id, url: response.url}));
  });
}
